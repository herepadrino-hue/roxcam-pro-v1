================================================================================
                          ROXCAM PRO V1.0.0
                    Advanced CCTV System for FiveM
                         Developed by RoxDev
================================================================================

Thank you for purchasing RoxCam Pro! Please read this entire file carefully before installation.

================================================================================
                            INSTALLATION STEPS
================================================================================

1. Extract the downloaded ZIP file to your desktop.

2. Rename the folder to "ny-camera" or any name you prefer. ("ny" based on my discord name NYROX)

3. Move the folder into your server's resources directory (example: server-data/resources/[police]/ny-camera).

4. Open your server.cfg file and add this line: ensure ny-camera

5. Open config.lua and follow the configuration guide below.

6. If using ESX or QBCore, import the SQL file into your database using phpMyAdmin or HeidiSQL.

7. Restart your server completely.

8. Join your server and test the camera system!

================================================================================
                        CONFIGURATION GUIDE (config.lua)
================================================================================

--------------------------------------------------------------------------------
FRAMEWORK SELECTION (Line 3)
--------------------------------------------------------------------------------

Config.Framework = 'standalone'

Change this to match your server's framework: 'standalone', 'esx', or 'qbcore'.

If you don't use ESX or QBCore, leave it as 'standalone' - the script will work for everyone on your server.

--------------------------------------------------------------------------------
DISCORD WEBHOOK - ⚠️ EXTREMELY IMPORTANT! ⚠️ (Line 5)
--------------------------------------------------------------------------------

Config.ScreenshotWebhook = 'YOUR_WEBHOOK_URL_HERE'

YOU MUST REPLACE THIS WITH A REAL DISCORD WEBHOOK OR CAMERA PLACEMENT WILL NOT WORK!

How to get a Discord webhook:
1. Open your Discord server and select any channel.
2. Right-click the channel → Edit Channel → Integrations → Webhooks.
3. Click "New Webhook" and copy the webhook URL.
4. Paste the URL into config.lua replacing the placeholder text.

Example: Config.ScreenshotWebhook = 'https://discord.com/api/webhooks/123456789/abcdefghijklmnop'

Why this matters: When you place a camera, the system captures a screenshot of the camera's view and uploads it to Discord, then uses that image as the live preview in your monitoring station.

--------------------------------------------------------------------------------
UI KEYBIND (Line 7)
--------------------------------------------------------------------------------

Config.UIKeybind = 'E'

This is the key players press to open the monitoring station interface when standing at the marker.

You can change 'E' to any other key if needed.

--------------------------------------------------------------------------------
MONITORING STATION LOCATION (Lines 9-16)
--------------------------------------------------------------------------------

Config.MonitoringStation = {
    coords = vector3(441.05, -978.72, 30.69),
    markerType = 27,
    markerSize = { x = 1.5, y = 1.5, z = 1.0 },
    markerColor = { r = 0, g = 100, b = 255, a = 100 },
    drawDistance = 10.0,
    interactionDistance = 2.0
}

The "coords" line sets where the monitoring station marker appears (default is Mission Row Police Station).

To change the location, replace the coordinates with your desired location (use /getcoords or similar commands in-game).

The markerColor values are Red, Green, Blue, and Alpha (transparency) - adjust these to change the marker's appearance.

--------------------------------------------------------------------------------
POLICE JOBS (Lines 18-21)
--------------------------------------------------------------------------------

Config.PoliceJobs = {
    'police',
    'sheriff'
}

Add or remove job names here to control which jobs can access the camera system.

If using standalone mode, everyone can access cameras regardless of this setting.

For ESX/QBCore, only players with these job names will see the monitoring station marker and access cameras.

--------------------------------------------------------------------------------
VIEW CAMERA PERMISSIONS (Lines 23-26)
--------------------------------------------------------------------------------

Config.ViewCamerasGrades = {
    ['police'] = { 0, 1, 2, 3, 4, 5, 6, 7 },
    ['sheriff'] = { 0, 1, 2, 3, 4, 5, 6, 7 },
}

These numbers represent job grades that can VIEW cameras (but not manage them).

Example: If you only want officers grade 2 and above to view cameras, change it to { 2, 3, 4, 5, 6, 7 }.

In standalone mode, this setting is ignored and everyone can view cameras.

--------------------------------------------------------------------------------
MANAGE CAMERA PERMISSIONS (Lines 28-31)
--------------------------------------------------------------------------------

Config.ManageCamerasGrades = {
    ['police'] = { 3, 4, 5, 6, 7 },
    ['sheriff'] = { 3, 4, 5, 6, 7 },
}

These grades can place, rename, edit, and delete cameras (usually sergeants and above).

Example: Only allow captains (grade 5+) to manage cameras: { 5, 6, 7 }.

In standalone mode, everyone can manage cameras.

--------------------------------------------------------------------------------
CAMERA OBJECT MODEL (Line 33)
--------------------------------------------------------------------------------

Config.CameraObject = 'prop_cctv_cam_01a'

This is the 3D prop that appears in the world when you place a camera.

You can change this to any other CCTV camera prop if you prefer a different look (examples: 'prop_cctv_cam_02a', 'prop_cctv_cam_03a', etc).

--------------------------------------------------------------------------------
CAMERA CONTROLS (Lines 34-38)
--------------------------------------------------------------------------------

Config.CameraRotationSpeed = 0.0
Config.CameraRotationRange = 90
Config.ManualRotationSpeed = 0.5
Config.ManualTiltRange = { min = -30, max = 30 }
Config.ManualPanRange = { min = -45, max = 45 }

These control how cameras move when viewing them - you can adjust the speed and range limits for camera pan/tilt movements.

Most users can leave these at default values.

--------------------------------------------------------------------------------
PLACEMENT COMMAND (Lines 49-51)
--------------------------------------------------------------------------------

Config.PlacementCommand = 'nycm'
Config.PlacementHeight = 3.0
Config.MaxCameras = 50

The "PlacementCommand" is what players type to start placing a camera (default: /nycm).

"PlacementHeight" is how high above ground the camera starts when placing (3.0 meters default).

"MaxCameras" limits how many cameras can exist on your server (default 50, increase if needed).

--------------------------------------------------------------------------------
CAMERA SETTINGS (Lines 53-58)
--------------------------------------------------------------------------------

Config.CameraFOV = 50.0
Config.NightVisionKey = 78
Config.ThermalVisionKey = 84
Config.ZoomInKey = 96
Config.ZoomOutKey = 97
Config.ToggleCursorKey = 244

These are key codes for camera view controls - most users should leave these as default.

FOV controls the camera's field of view (lower = more zoomed in, higher = wider view).

--------------------------------------------------------------------------------
POSTAL CODES (Lines 76-79)
--------------------------------------------------------------------------------

Config.PostalCodes = {
    [1] = { coords = vector3(425.1, -979.5, 30.7), code = "3201" },
    [2] = { coords = vector3(1854.9, 3686.6, 34.3), code = "8072" },
}

This system auto-detects the nearest postal code when placing cameras just ignore them.

Add more postal codes here if your server uses a postal code system (format shown above).

If you don't use postal codes, you can leave this as is or empty the table.

================================================================================
                            DATABASE SETUP
================================================================================

If using ESX or QBCore, you MUST import the SQL file:

1. Open phpMyAdmin, HeidiSQL, or your preferred MySQL management tool.

2. Select your server's database.

3. Click "Import" or "Execute SQL File".

4. Select the "lspd_cameras.sql" file included in the package.

5. Execute/Import the file.

This creates a table called "lspd_cameras" which stores all camera data.

If using standalone mode, skip this step entirely - no database needed!

================================================================================
                            DEPENDENCIES
================================================================================

REQUIRED DEPENDENCY:

- screenshot-basic (https://github.com/citizenfx/screenshot-basic)

Download screenshot-basic, place it in your resources folder, and add to server.cfg: ensure screenshot-basic

This dependency is REQUIRED for camera screenshot functionality to work!

OPTIONAL DEPENDENCIES (only if using ESX/QBCore):

- oxmysql (for database functions)
- es_extended (if using ESX)
- qb-core (if using QBCore)

Standalone mode has no dependencies except screenshot-basic!

================================================================================
                            TROUBLESHOOTING
================================================================================

PROBLEM: Camera placement doesn't work or gets stuck.
SOLUTION: Make sure your Discord webhook is configured correctly in config.lua and screenshot-basic is installed.

PROBLEM: Monitoring station marker doesn't appear.
SOLUTION: Check that your job name matches Config.PoliceJobs if using ESX/QBCore, or set Config.Framework to 'standalone'.

PROBLEM: Cameras don't save after server restart.
SOLUTION: Ensure you imported the SQL file and oxmysql is running (for ESX/QBCore only).

PROBLEM: Players can't view cameras.
SOLUTION: Check Config.ViewCamerasGrades to ensure their job grade is included in the list.

PROBLEM: Screenshot upload fails.
SOLUTION: Verify your Discord webhook URL is correct and the Discord channel still exists.

PROBLEM: Script errors in console.
SOLUTION: Ensure screenshot-basic is started BEFORE roxcam-pro in your server.cfg.

================================================================================
                            FINAL CHECKLIST
================================================================================

Before starting your server, verify:

✓ Framework is set correctly in config.lua
✓ Discord webhook URL is configured (CRITICAL!)
✓ screenshot-basic is installed and added to server.cfg
✓ SQL file is imported (if using ESX/QBCore)
✓ Police job names match your server's jobs
✓ Resource is added to server.cfg: ensure roxcam-pro

================================================================================
                            USAGE IN-GAME
================================================================================

TO ACCESS MONITORING STATION:
Walk up to the monitoring station marker (default: Mission Row PD) and press E.

TO PLACE A CAMERA:
Type the command /nycm (or your configured command), enter a camera name, then use WASD/Z/X to position and arrow keys to rotate the camera, press ENTER to confirm.

TO VIEW A CAMERA:
Open the monitoring station and click the eye icon on any camera card.

TO MANAGE CAMERAS:
Click the settings icon on a camera card to edit name/location/notes, or the trash icon to delete.

================================================================================
                            LICENSE & TERMS
================================================================================

This purchase grants you a single-server license for RoxCam Pro.

You MAY: Modify the source code for your own server, customize features, rebrand the UI for your community.

You MAY NOT: Resell this script, redistribute it publicly, share it with other servers, claim it as your own work.

No refunds are provided for digital products after download.

No official support is included - you are responsible for installation and configuration using this README file.

================================================================================
                            THANK YOU!
================================================================================

Thank you for purchasing RoxCam Pro by RoxDev!

If you enjoy this script, please consider leaving a review on Tebex and checking out my future releases!

Developed with ❤️ by RoxDev | Version 1.0.0 | © 2025

================================================================================